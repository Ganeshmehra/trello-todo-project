# Trello UI Styled To-Do
A todo app based on the trello website UI having the "Todo","Doing" and "Done" boards and allowing drag and drop operations with simple HTML5 drag and drop API.

Check out live example at [todo@GLITCH.me](https://trello-todo.glitch.me/)

![Image of the application](https://i.ibb.co/dQSBs55/Screenshot-2021-01-15-165134.png)

